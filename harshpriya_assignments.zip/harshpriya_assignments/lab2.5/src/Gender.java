

	public enum Gender {
		

		m,M,f,F;
	}
	

