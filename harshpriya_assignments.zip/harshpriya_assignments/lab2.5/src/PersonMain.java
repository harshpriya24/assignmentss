
public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Person person=new Person("Harsh","Priya",Gender.F,876654);
     System.out.println("Personal Details");
     System.out.println("-----------------------");
     System.out.println("First Name: "+person.getFirstName());
     System.out.println("Last Name :"+person.getLastName());
     System.out.println("Gender :"+person.getGender());
     	}

}
