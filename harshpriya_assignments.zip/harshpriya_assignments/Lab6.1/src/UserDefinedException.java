
public class UserDefinedException extends Exception
{
  public UserDefinedException() 
  {
	System.out.println("Either the First Name or Last Name is Blank");
  }
}
