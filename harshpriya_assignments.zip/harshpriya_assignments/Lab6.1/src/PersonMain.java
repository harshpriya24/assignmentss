import java.util.Scanner;


public class PersonMain {

	public static void main(String[] args) throws UserDefinedException {
		Person person=new Person();
		Scanner sc=new Scanner(System.in);
		String fn,ln;
		String gen;
		System.out.println(" Enter First Name");
		fn=sc.next();
		person.setFirstName(fn);
		System.out.println("enter Last Name");
		ln=sc.next();
		person.setLastName(ln);
		System.out.println("Enter gender");
	    gen=sc.next();
	    person.setGender(gen);
	    person.dispEmp();
		
		
        
        
	}

}
