import java.util.Scanner;


public class Person extends Exception
{
    Scanner sc=new Scanner("System.in");
	String firstName,lastName;
	String gender;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName)throws UserDefinedException 
	{
		if(firstName.isEmpty()==true)
		{
			throw new UserDefinedException();
		}
		else
		this.firstName = firstName;
		
	}
	public String getLastName()  {
		return lastName;
	}
	public void setLastName(String lastName) throws UserDefinedException
	{
		if(lastName.isEmpty()==true)
		{
			throw new UserDefinedException();
		}
		else
		{
		this.lastName = lastName;
       	}
    }
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
     public Person()
     {
    	 firstName=" ";
    	 lastName=" ";
    	 gender=" ";
     }
     public Person(String firstName,String lastName,String gender)
     {
    	 this.firstName=firstName;
    	 this.lastName=lastName;
    	 this.gender=gender;
    	 this.dispEmp();
     }
     
     
    public void dispEmp()
    {
    	System.out.println("Person Details");
    	System.out.println("----------------------");
    	System.out.println("First Name :"+firstName);
    	System.out.println("Last Name :"+lastName);
    	System.out.println("Gender :"+gender);
    	    }
}
