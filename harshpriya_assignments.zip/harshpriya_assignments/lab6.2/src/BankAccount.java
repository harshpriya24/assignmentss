import java.util.Scanner;


public class BankAccount {

	public static void main(String[] args) throws UserDefinedException {
		
      Scanner sc=new Scanner(System.in);
      Person smith =new Person();
      Person kathy =new Person();
      Account accSmith=new Account();
      Account accKathy=new Account();

      long accNum=(long)(Math.random()*100000);
      accSmith.setAccHolder(smith);
      smith.setName("Smith");
      smith.setAge(22);
      accSmith.setBalance(2000);
      accSmith.setBalance(accNum);
      System.out.println(accSmith.toString());
      System.out.println("After Updation ");
      accSmith.deposit(2000);
      System.out.println(accSmith.toString());
      
      accNum=(long)(Math.random()*100000);
      accKathy.setAccHolder(kathy);
      kathy.setName("kathy");
      kathy.setAge(25);
      accKathy.setBalance(2000);
      accKathy.setBalance(accNum);
      System.out.println(accKathy.toString());
      System.out.println("After Updation ");
      accKathy.deposit(2000);
      System.out.println(accKathy.toString());
      
      
	}

}
