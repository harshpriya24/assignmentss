
public class UserDefinedException extends Exception
{
    public UserDefinedException() 
    {
	  System.out.println("Age should be greater than 15");
	}
}
