
public class Person 
{
	private String Name;
	private float age;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) throws UserDefinedException{
		if(age>15){
		this.age = age;
			}
		else
		{
			throw new UserDefinedException();
		}
		}
	

}
