import java.util.Scanner;


public class StringOp 
{
  public static void main(String[] args){
	  String string;
      Scanner sc=new Scanner(System.in);
      System.out.println("enter the String");
      string=sc.next();
	 
      System.out.println("Choose Operations");
	  System.out.println("Press 1 to Add the string to itself.");
	  System.out.println("Press 2 to Replace the odd positions with #.");
	  System.out.println("Press 3 to Remove the duplicate characters in the String.");
	  System.out.println("Press 4 to Change the odd characters to UppperCase.");
	 
   
     int index=sc.nextInt();
     switch(index){
     case 1: string=string.concat(string);
             System.out.println("Added String=: "+" "+string);
             break;
     case 2:  String str=" ";
    	      char[] st=string.toCharArray();
    	    for(int i=0;i<st.length;i++)
             {
    	       if(i%2==0)
    	       {
    	    	  st[i]='#';
    	       }
             }
    	    str=new String(st);
            System.out.println("replaced:-"+str);
     case 3: String stri=" ";
             for(int i=0;i<string.length();i++)
             {
            	 if(!stri.contains(String.valueOf(string.charAt(i))))
            		 {
            		    stri=String.valueOf(string.charAt(i));
            		 }           	 
             }
             System.out.println("the newword after removing duplicates"+" "+stri);
             break;
     case 4: String str2=" ";
             char[] nword2=string.toCharArray();
              for(int i=0;i<nword2.length;i++)
              {
            	  if(i%2==0)
            	  {
            		 nword2[i]=Character.toUpperCase(nword2[i]); 
            	  }
              }
              str2=new String(nword2);
            		  
              System.out.println(str2);
              break;
      default: System.out.println("not applicable");        
    	 
     }
}
}
