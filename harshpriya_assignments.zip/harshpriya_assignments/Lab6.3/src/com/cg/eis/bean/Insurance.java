package com.cg.eis.bean;

public enum Insurance 
{
  SchemeA,SchemeB,SchemeC,NoScheme;
}
