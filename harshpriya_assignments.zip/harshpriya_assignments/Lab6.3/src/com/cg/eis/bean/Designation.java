package com.cg.eis.bean;

public enum Designation 
{
  clerk,manager,programmer,systemassociate;
}
