package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.*;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeServiceMain;

public class UserInput 
{
  public static void main(String[] args) throws EmployeeException
  {
	  Scanner sc=new Scanner(System.in);
	  int i;
	  System.out.println("Enter the number of employees");
	  int noOfEmployee=sc.nextInt();
	  EmployeeServiceMain employee=new EmployeeServiceMain(noOfEmployee);
	  
	  for(i=0;i<noOfEmployee;i++)
	  {
		  System.out.println("enter the employee id");
		  int eId=sc.nextInt();
		  System.out.println("Enter the Employee Salary");
		  double eSalary=sc.nextDouble();
		  System.out.println("enter the name");
		  String name=sc.next();
		  System.out.println("Enter Designation");
		  Designation eDesignation=null;
		  System.out.println("1. System engineer,2. Manager,3.Clerk,4.Programmer");
		  System.out.println("Enter your Designation");
		  int ch=sc.nextInt();
		  switch(ch)
		  {
		  case 1:eDesignation=Designation.systemassociate;
		  break;
		  case 2:eDesignation=Designation.manager;
		  break;
		  case 3:eDesignation=Designation.clerk;
		  break;
		  case 4:eDesignation=Designation.programmer;
		  break;
		  default : eDesignation=Designation.programmer;
		  }
	  
	      Insurance eInsuranceScheme=employee.findEmployeeInsurance(eSalary, eDesignation);
	      employee.add(i, eId, name, eSalary, eDesignation,eInsuranceScheme);
	  
	  }
	  for(i=0;i<noOfEmployee;i++)
	  {
		  System.out.println(" "+employee.employeeDetail(i));
	  }
  } 
}
