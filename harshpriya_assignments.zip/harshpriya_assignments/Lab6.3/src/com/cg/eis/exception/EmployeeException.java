package com.cg.eis.exception;

public class EmployeeException extends Exception {
 public EmployeeException() {
	System.out.println("Salary is below 3000");
}
}
