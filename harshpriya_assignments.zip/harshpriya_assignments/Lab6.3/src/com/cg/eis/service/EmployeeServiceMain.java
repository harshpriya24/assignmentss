package com.cg.eis.service;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Employee;
import com.cg.eis.bean.Insurance;
import com.cg.eis.exception.EmployeeException;

public class EmployeeServiceMain implements EmployeeService
{
	private int noOfEmployee;
	private Employee empList[];
	public EmployeeServiceMain(int noOfEmployee) 
	{
	  this.empList=new Employee[noOfEmployee];
	}

	@Override
	public void add(int i,int empId, String empName, double empSal,
			Designation designation,Insurance ins)
	{  if(empSal>3000){
	   if(i>=0 && i<this.empList.length)
	   {
		   empList[i]=new Employee(empId,empName,empSal,designation,ins);
	   } else
		try {
			throw new EmployeeException();
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
	}
	}

	@Override
	public Insurance findEmployeeInsurance(double eSalary,
			Designation eDesignation)
	{
		if(eSalary>3000){
	   if(eSalary>5000 && eSalary<20000)
	   {
		   return Insurance.SchemeC;
	   }
	   else if(eSalary>=20000 && eSalary<40000)
	   {
		   return Insurance.SchemeB;
	   }
	   else if(eSalary>=40000)
	   {
		   return Insurance.SchemeA;
	   }
	   else if(eSalary<5000)
	   {
		   return Insurance.NoScheme;
	   }

		}
		else
		{
			try {
				throw new EmployeeException();
			} catch (EmployeeException e) {
				e.printStackTrace();
			}
		}
		return null;
	   
	}

	@Override
	public String employeeDetail(int i) {
	
		return this.empList[i].toString();
	}

}
