package com.cg.eis.service;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Insurance;

public interface EmployeeService 
{
	public abstract void add(int i,int empId, String empName, double empSal,
			Designation designation,Insurance ins);
	public abstract Insurance findEmployeeInsurance(double eSalary,Designation eDesignation);
	public abstract String employeeDetail(int i);
}
