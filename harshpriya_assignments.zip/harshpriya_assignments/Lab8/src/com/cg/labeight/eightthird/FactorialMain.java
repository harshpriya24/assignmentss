package com.cg.labeight.eightthird;

public class FactorialMain {
	public static void main(String[] args) throws InterruptedException {
		FactorialPrint resource=new FactorialPrint();
		
		Thread th1=new Thread(resource,"FirstThread");
		Thread th21 = new Thread(new FactorialPrint(5));
		th1.start();
		th21.start();
		System.out.println("Main Thread End Here");
		}
}
