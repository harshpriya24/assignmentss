package com.cg.labeight.eightthird;

public class FactorialPrint implements Runnable{
	
		int f,n;
		public FactorialPrint(int i) {
			n=i;
		}
		public FactorialPrint() {
		}
		@Override
		public void run() {
			Thread t=Thread.currentThread();
			if(t.getName().equals("FirstThread"))
			{
				System.out.println(Math.random()*1000);
			}

				f=1;
					for(int i=1;i<=n;i++) {
						f=f*i;
								
					System.out.println(f);

			}
		}
	}
