package com.cg.labeight.eighttwo;

import java.util.Timer;
import java.util.TimerTask;

public class RefreshTimer {

	
	    Timer timer;

	  public RefreshTimer(int seconds) {
	        timer = new Timer();
	        timer.schedule(new RemindTask(),seconds*1000);
		}

	    class RemindTask extends TimerTask {
	        public void run() {
	            System.out.println("Time's up!");
	            timer.cancel(); //Terminate the timer thread
	        }
	    }

	    public static void main(String args[]) {
	        new RefreshTimer(10);
	        System.out.println("Task scheduled.");
	    }
	}

