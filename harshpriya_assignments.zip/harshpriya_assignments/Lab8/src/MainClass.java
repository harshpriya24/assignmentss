
public class MainClass {
	
		public static void main(String[] args) {
			
			String sourceFile = "D:\\New folder\\source.txt";
			String targetFile = "D:\\New folder\\target.txt";
			
			CopyDataThread copyThread = new CopyDataThread(sourceFile, targetFile);
			
			Thread copy = new Thread(copyThread);
			copy.start();
			try {
				copy.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
	}

} 
