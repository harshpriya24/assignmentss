import java.util.Scanner;



public class MainClass {
	public static void main(String[] args) {
	LambdaExpressionForXToPowerY xy=(x,y)->Math.pow(x, y);
	double x=xy.xToThePowerY(2, 4);
	System.out.println(x);
	
	System.out.println("-----------------Space---11.2----------------------------");
	Scanner sc=new Scanner(System.in);
	 System.out.println("Enter ");
	String str1=sc.next();
	SpaceInterface space=(s)->str1.replace(""," ");
	String str=space.space(str1);
	System.out.println(str);
	
	System.out.println("------------------UserName 11.3------------------------------------------");
	String userName="Harshu";
	String password="harshu1234";
	System.out.println("Enter username"); 
	String uI=sc.next(); 
	System.out.println("Enter Password");
	String pI=sc.next();
	AcceptUserPass accept=(u,p)->{if(u.equals(userName)&&(p.equals(password)))
		return true;
	else return false;
	};
    boolean b=accept.customcheck(uI, pI);
    System.out.println(b);
	System.out.println("----------------------------Question 4--------------------");
	
	
	}
}

