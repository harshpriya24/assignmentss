
public interface AcceptUserPass {
 public boolean customcheck(String userName,String passWord);
}
