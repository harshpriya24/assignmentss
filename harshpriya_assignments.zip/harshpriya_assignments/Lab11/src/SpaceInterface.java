

public interface SpaceInterface {
 public  String space(String x); 
}
