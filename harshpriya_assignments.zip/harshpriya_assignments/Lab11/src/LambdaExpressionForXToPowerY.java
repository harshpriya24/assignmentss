
public interface LambdaExpressionForXToPowerY {
 public double xToThePowerY(int x,int y);
}
