
public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person=new Person("Harsh","Priya",'F',987876);
        Person person1=new Person("Garima","Sharma",'F',5436698);
	}

}
