

import java.util.Scanner;


	public class Person {
	    Scanner sc=new Scanner("System.in");
		String firstName,lastName;
		char gender;
		long phonenum;
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public char getGender() {
			return gender;
		}
		public void setGender(char gender) {
			this.gender = gender;
		}
		
	     public Person()
	     {
	    	 firstName=" ";
	    	 lastName=" ";
	    	 gender=' ';
	     }
	     public Person(String firstName,String lastName,char gender,long phonenum)
	     {
	    	 this.firstName=firstName;
	    	 this.lastName=lastName;
	    	 this.gender=gender;
	    	 this.phonenum=phonenum;
	    	 this.dispEmp();
	     }
	     public long acptph() 
	     {
	    	 System.out.println("Enter the Phone number");
	    	 phonenum=sc.nextLong();
	          return phonenum;
	     }
	    public void dispEmp()
	    {
	    	System.out.println("Person Details");
	    	System.out.println("----------------------");
	    	System.out.println("First Name :"+firstName);
	    	System.out.println("Last Name :"+lastName);
	    	System.out.println("Gender :"+gender);
	    	System.out.println("phone number :"+phonenum);
	    }
	}

