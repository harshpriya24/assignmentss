
public class PersonMain {

	public static void main(String[] args) {
		Person person=new Person("Harsh","Priya",'F');
        Person person1=new Person("Garima","Sharma",'F');
	}

}
