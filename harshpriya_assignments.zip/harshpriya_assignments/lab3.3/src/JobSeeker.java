import java.util.Scanner;


public class JobSeeker
{
	public static void main(String[] args)
	{
       Scanner sc=new Scanner(System.in);
       System.out.println("Enter the name");
       String userName=sc.next();
       boolean result;
       if((userName.length()-4)>=8 && userName.endsWith("_job"))
       {
    	   result=true;
       }
       else
       {
    	   result=false;
       }

       if(result==true)
       {
    	   System.out.println("Validation Passed");
       }
       else
       {
    	   System.out.println("Validation failed");
       }
	}

}
