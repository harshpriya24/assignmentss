import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;


public class SortAlphabets 
{

	public static void main(String[] args) 
	{ int n;
	String temp=" ";
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter the number of alphabets you want to enter");
	  n=sc.nextInt();
	  String[] alp=new String[n];
	  for(int i=0;i<alp.length;i++)
	  {
		  alp[i]=sc.next();
	  }
	  
	  for(int j=0;j<alp.length-1;j++)
	  {
		 for(int k=j+1;k<alp.length;k++)
		 {
			 if(alp[j].compareTo(alp[k])>0)
			 {
	               temp = alp[j];
	               alp[j] = alp[k];
	               alp[k] = temp;
		     }
    	    
		 }
	  }
		 System.out.println(Arrays.toString(alp));
		 int l=alp.length;
		 if(l%2==0)
		 {
			 for(int i=0;i<l/2;i++)
			 {
		     	System.out.println(alp[i].toUpperCase()); 
		     }
			 for(int j=l/2;j<l;j++)
			 {
				 System.out.println(alp[j].toLowerCase());
			 }
	     }
		 else
		 {
			 for(int i=0;i<(l+1)/2;i++)
			 {
				 System.out.println(alp[i].toUpperCase());
			 }
			 for(int j=(l+1)/2;j<l;j++)
			 {
				 System.out.println(alp[j].toLowerCase());
			 }
			 
		 }
	    
}
	}


