import java.time.LocalDate;
import java.util.Scanner;


public class WarrantyDate {

	public static void main(String[] args)
	{
		System.out.println("Enter the Purchase Date");
		Scanner sc=new Scanner(System.in);
		String purDate=sc.next();
		purDate=purDate+" ";
		int dd=Integer.parseInt(purDate.substring(0,2));
		int mm=Integer.parseInt(purDate.substring(3,5));
		int yyyy=Integer.parseInt(purDate.substring(6,10));
		LocalDate purchaseDate=LocalDate.of(yyyy, mm, dd);
        
		System.out.println("Enter the warranty period");
		String warPeriod=sc.next();
		warPeriod=warPeriod+" ";
		int mm1=Integer.parseInt(warPeriod.substring(0,2));
		int yy=Integer.parseInt(warPeriod.substring(3,7));
		purchaseDate=purchaseDate.plusMonths(mm1);
		purchaseDate=purchaseDate.plusYears(yy);
		System.out.println("Product expiry date"+purchaseDate);
		
	}

}
