import java.time.ZoneId;
import java.util.Scanner;


public class zoneID 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter zoneId");
		String str= sc.next();
		System.out.println("Current date and time:" +java.time.LocalDateTime.now(ZoneId.of(str)));
	    
	}
	
}
