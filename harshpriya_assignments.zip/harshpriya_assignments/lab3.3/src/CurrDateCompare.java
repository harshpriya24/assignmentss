import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.util.Date;
import java.util.Scanner;


public class CurrDateCompare 
 {  
	public static void main(String[] args){
		
   Scanner sc=new Scanner(System.in);
   LocalDate currentDate=java.time.LocalDate.now();
   System.out.println("current Date="+currentDate);
	System.out.println("enter the String in dd-mm-yyyy");
	String str=sc.next();
	str=str+" ";
	int dd=Integer.parseInt(str.substring(0,2));
	int mm=Integer.parseInt(str.substring(3,5));
	int yyyy=Integer.parseInt(str.substring(6,10));
	LocalDate newDate=LocalDate.of(yyyy, mm, dd);
	Period duration= Period.between(currentDate, newDate);
	System.out.println("Difference is :"+duration.getYears()+"years"+duration.getMonths()+"months"+duration.getDays()+"Days");
	
	}
	
 }

