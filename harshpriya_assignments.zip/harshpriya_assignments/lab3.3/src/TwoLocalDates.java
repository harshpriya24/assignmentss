import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class TwoLocalDates 
{
	public static void main(String[] args){
   Scanner sc=new Scanner(System.in);
   
  
    System.out.println("First Date=");
  	System.out.println("enter the String in dd-mm-yyyy");
  	String date1=sc.next();
  	date1=date1+" ";
    int dd=Integer.parseInt(date1.substring(0,2));
	int mm=Integer.parseInt(date1.substring(3,5));
	int yyyy=Integer.parseInt(date1.substring(6,10));
	LocalDate firstDate=LocalDate.of(yyyy, mm, dd);
   
	System.out.println("Second Date=");
	System.out.println("enter the String in dd-mm-yyyy");
	String date2=sc.next();
	date2=date2+" ";
	int dd2=Integer.parseInt(date2.substring(0,2));
	int mm2=Integer.parseInt(date2.substring(3,5));
	int yyyy2=Integer.parseInt(date2.substring(6,10));
	LocalDate secondDate=LocalDate.of(yyyy2, mm2, dd2);
	
	Period duration= Period.between(firstDate, secondDate);
	System.out.println("Difference is :"+duration.getYears()+"years"+duration.getMonths()+"months"+duration.getDays()+"Days");
	
	
	
	}
}
