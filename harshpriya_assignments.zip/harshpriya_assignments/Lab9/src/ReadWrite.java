import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;


public class ReadWrite {

	public static void main(String[] args) {
      String s1="";
      String s2="";
      int c=0;
      try {
		FileInputStream filein=new FileInputStream("d:\\source.txt");
		  while((c=filein.read())!=-1){
			  s1+=Character.toString((char)c);
		  }
	} catch (FileNotFoundException e) {
	    e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}
      FileOutputStream fileout;
      s2=ReverseString.revString(s1);
      for(int i=0;i<=s2.length();i++){
    	  try {
			fileout=new FileOutputStream("d:\\source.txt");
			  fileout.write(s2.charAt(i));
		} catch (FileNotFoundException e) {
			   e.printStackTrace();
		} catch (IOException e) {
			   e.printStackTrace();
		}
    	  
      }
      System.out.println("File Copied");
	}

}
