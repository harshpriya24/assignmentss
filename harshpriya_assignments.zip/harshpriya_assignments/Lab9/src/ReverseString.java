
public class ReverseString {

	public static String revString(String s1) {
		// TODO Auto-generated method stub
		return null;
	}

}
