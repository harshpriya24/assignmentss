package com.cg.nine.ninetwo;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class NumberClass {

	public static void main(String[] args) throws Exception {

	    List<Integer> list = new ArrayList<Integer>();
	    System.out.println("Reading a text file word by word: ");
	    Scanner sc = new Scanner(new File("D:\\file.txt"));
	    while (sc.hasNext()) {
	      String word = sc.next();
	      String[] a = word.split(",");
	      System.out.println(word);
	    for(int i=0;i<a.length;i++)
	    {
	    	Integer a1 = Integer.parseInt(a[i]);
	    	if(a1%2==0)
	    	{
	    		list.add(a1);
	    	}
	    }
	    System.out.println(list);

	  }
	    sc.close();
 }
}
