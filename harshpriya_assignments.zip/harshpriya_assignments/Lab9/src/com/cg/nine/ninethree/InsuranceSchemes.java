package com.cg.nine.ninethree;

public enum InsuranceSchemes {
	SchemeA, SchemeB, SchemeC, NoSchemes

}
