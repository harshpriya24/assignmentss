package com.cg.nine.ninethree;

public enum Designations {
	Manager, Programmer, SystemAssociate, Clerk

}
