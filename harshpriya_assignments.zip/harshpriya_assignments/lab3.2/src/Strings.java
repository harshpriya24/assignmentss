import java.util.Scanner;


public class Strings 
{
  public boolean CheckString(String str)
  {
	 for(int i=0;i<str.length()-1;i++)
	 { 
		if(str.charAt(i)<str.charAt(i+1))
			//System.out.println(str.charAt(i));
			return false ; 
			
	 }
	 return true;
  } 
  public static void main(String[] args)
  {
	String str;
	Scanner sc =new Scanner(System.in);
	str=sc.next();
	Strings s=new Strings();
	boolean result=s.CheckString(str);
     if(result==true)
     {
    	 System.out.println("the String is Positive");
         }	
     else
     {
    	 System.out.println("the String is negative");
     }
	
  }
  
}
