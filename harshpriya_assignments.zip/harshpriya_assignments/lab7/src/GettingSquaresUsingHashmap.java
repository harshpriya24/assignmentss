import java.util.HashMap;
import java.util.Scanner;


public class GettingSquaresUsingHashmap {

	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter the array size");
     int size=sc.nextInt();
     int arr[]=new int[size];
     System.out.println("Enter the array Elment");
     for(int i=0;i<size;i++)
    	 arr[i]=sc.nextInt();
     HashMap<Integer, Integer> hashArray=getSquares(arr);
     System.out.println(hashArray);

	}

	private static HashMap<Integer, Integer> getSquares(int[] arr) {
	 HashMap<Integer, Integer> hashArray=new HashMap<>();
	 for(int i=0;i<arr.length;i++)
		 hashArray.put(arr[i],arr[i]*arr[i]);
		return hashArray;
	}

}
