import java.util.ArrayList;
import java.util.Scanner;


public class ElementRemovalList {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of element in the list");
		int count=sc.nextInt();
		ArrayList<String> list1=new ArrayList<>();
		for(int i=0;i<count;i++){
			list1.add(sc.next());

			System.out.println("Enter the number of the element in list2");
			count=sc.nextInt();
			ArrayList<String> list2= new ArrayList<>();
			for(int i2=0;i2<count;i2++){
				list2.add(sc.next());
				ArrayList<String> list3=removeElements(list1,list2);
				System.out.println("elements in th elist after removal");
				for(int j=0;j<list3.size();j++){
					System.out.println(list3.get(j));
				};


			}

		}
	}

	private static ArrayList<String> removeElements(ArrayList<String> list1,
			ArrayList<String> list2) {
		list1.removeAll(list2);
		return list2;
	}

}
