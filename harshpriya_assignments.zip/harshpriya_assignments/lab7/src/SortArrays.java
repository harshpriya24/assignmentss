import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;


public class SortArrays {
	int n;
	public static int[] getSorted(int arr[]){
	ArrayList<Integer> arrList=new ArrayList<>();
	for(int i=0;i<arr.length;i++){
		int copy=arr[i],rev=0;
		while(copy>0){
			int d=copy%10;
			rev=rev*10+d;
			copy=copy/10;
		}
	 arrList.add(i,rev);
	}
          	Collections.sort(arrList);
	        for(int i=0;i<arr.length;i++){
	        	arr[i]=arrList.get(i);
	        }
	return arr;
	}
		public static void main(String[] args){
			int i,n;
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the number of elements");
			n=sc.nextInt();
			int arr[]=new int[n];
			System.out.println("Enter the array Element");
			for(i=0;i<n;i++){
				arr[i]=sc.nextInt();
			}
			int nArray[]=getSorted(arr);
			for(i=0;i<n;i++){
				System.out.println(nArray[i]);
			}
		}
}

