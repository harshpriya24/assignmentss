package com.cg.date.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.date.beans.Date;

public class DateTest {

	@Test
	public void testGetDay(){
	Date date=new Date(03, 06, 1998);
	assertEquals(03, date.getDay());
		
	}

}
