package com.cg.date.beans;

public class Date {
	private int Day;
	private int Month;
	private int Year;
	
	public Date(int day, int month, int year) {
		
		this.Day = day;
		this.Month = month;
		this.Year = year;
	}
	public int getDay() {
		return this.Day;
	}
	public void setDay(int day) {
		this.Day = day;
	}
	public int getMonth() {
		return this.Month;
	}
	public void setMonth(int month) {
		this.Month = month;
	}
	public int getYear() {
		return this.Year;
	}
	public void setYear(int year) {
		this.Year = year;
	}
	@Override
	public String toString() {
		return "Date [Day=" + Day + ", Month=" + Month + ", Year=" + Year + "]";
	}

}
