
public class SavingsAccount extends Account
{

	   private long accNum;
	   private double balance;
      private static final int minimumbalance=2000;
      public SavingsAccount(long accNum,double balance,double amount)
      { this.accNum=accNum;
      this.balance=balance;
    	  
      }
       public void withdraw(double amount) throws InsufficientBalance
       { 
    	   if(balance-amount<minimumbalance)
         {
    	   balance-=amount;
         }
    	   else
    		   throw new InsufficientBalance();
     	  
       }
}
