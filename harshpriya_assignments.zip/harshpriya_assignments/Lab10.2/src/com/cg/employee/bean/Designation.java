package com.cg.employee.bean;

public enum Designation {
	clerk,manager,programmer,systemassociate;
}
