package com.cg.employee.bean;

public enum Insurance {
	  SchemeA,SchemeB,SchemeC,NoScheme;

}
