package com.cg.employee.bean;

import com.cg.employee.bean.Designation;
import com.cg.employee.bean.Insurance;
import com.cg.employee.exception.ExceptionCheck;

public class Employee {



	 public Insurance getIns() {
		return ins;
	}
	public void setIns(Insurance ins) {
		this.ins = ins;
	}
	int empId;
	 String empName;
	 double empSal;
	Designation designation;
	Insurance ins;
	
	public Employee(int empId, String empName, double empSal,
			Designation designation,Insurance ins) 
	{
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.designation = designation;
		this.ins=ins;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal)  {
		if(empSal>3000)
		this.empSal = empSal;
		else
			try {
				throw new ExceptionCheck();
			} catch (ExceptionCheck e) {
				e.printStackTrace();
			}
	}
	public Designation getDesignation() {
		return designation;
	}
	public void setDesignation(Designation designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName
				+ ", empSal=" + empSal + ", designation=" + designation + "Insurance Scheme is"+ins+"]";
	}
	
	
}
