package com.cg.employee.exception;

public class ExceptionCheck extends Exception {
	 public ExceptionCheck() {
			System.out.println("Salary is below 3000");
		}
}
