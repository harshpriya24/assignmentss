package com.cg.person.bean;

import static org.junit.Assert.*;

import org.junit.Test;

public class PersonTest {

	@Test
	public void testFirstName(){
		Person person=new Person("Harsh","Priya", 'F');
		assertEquals("Harsh", person.getFirstName());		
	}
	@Test
	public void testLastName(){
		Person person=new Person("Harsh","Priya", 'F');
		assertEquals("Priya", person.getLastName());
	}
	
	@Test
	public void testGender(){
		Person person=new Person("Harsh","Priya", 'F');
		assertEquals('F',person.getGender());
	}
}
