
public class Person {

	String fn,ln;
	char gender;
	int age;
	double weight;
	public String getFn()
	{
       fn="Divya";		
	  return fn;
	}
	public String getLn()
	{
		ln="Bharti";
		return ln;
	}
	public char getGender()
	{
		gender='F';
		return gender;
	
	}
	public double getWeight()
	{
		weight=85.55;
		return weight;
	}
	
	public int getAge()
	{
		age=20;
		return age;
	}
	
}
