
public class PersonDetails {

	public static void main(String[] args) {
		Person p=new Person();
		System.out.println("Personal Details");
		System.out.println();
		System.out.println("---------------");
		System.out.println("First Name : "+ p.getFn());
        System.out.println("Last Name  : "+ p.getLn());
        System.out.println("Gender : "+ p.getGender());
        System.out.println("Age :"+p.getAge());
        System.out.println("weight :"+p.getWeight());
        
	}

}
