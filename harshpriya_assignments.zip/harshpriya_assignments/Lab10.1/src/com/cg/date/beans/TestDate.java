package com.cg.date.beans;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDate {

	@Test
	public void testGetDay(){
		Date date=new Date(03,9,2356);
		assertEquals(03, date.getDay());
	}

	@Test
	public void testGetMonth(){
		Date date=new Date(03, 9, 2019);
		assertEquals(9, date.getMonth());
	}
	@Test
	public void testGetYear(){
		Date date=new Date(03, 9, 2019);
		assertEquals(2019, date.getYear());
	}
}
